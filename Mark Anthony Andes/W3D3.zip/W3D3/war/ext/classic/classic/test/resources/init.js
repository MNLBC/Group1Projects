addGlobal([
    'spec'
]);
