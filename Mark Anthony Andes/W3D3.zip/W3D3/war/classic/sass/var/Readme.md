### ./sass/var

This folder contains Sass files defining Sass variables corresponding to classes
included in the application's JavaScript code build when using the classic toolkit.
By default, files in this folder are mapped to the application's root namespace,
'W3D3' in the same way as `"W3D3/sass/src"`.