Ext.define('W3D3.view.register.Register', {
    extend: 'Ext.window.Window',
    xtype: 'register',

    requires: [
        'W3D3.view.register.RegisterController',
        'Ext.form.Panel'
    ],

    controller: 'register',
    bodyPadding: 10,
    title: 'Register Form',
    closable: false,
    autoShow: true,

    items: {
        xtype: 'form',
        reference: 'form',
		
        items: [{
            xtype: 'textfield',
            name: 'fullName',
            fieldLabel: 'Fullname',
            allowBlank: false
        },{
            xtype: 'textfield',
            name: 'email',
            fieldLabel: 'Email',
            allowBlank: false
        } ,{
            xtype: 'datefield',
            fieldLabel: 'Date of Birth',
            name: 'birthDate'
        },{
        xtype: 'numberfield',
        anchor: '100%',
        name: 'age',
        fieldLabel: 'Age',
        minValue: 0,
        hideTrigger: true,
        keyNavEnabled: false,
        mouseWheelEnabled: false
    },{
            xtype: 'textfield',
            name: 'username',
            fieldLabel: 'Username',
            allowBlank: false
        }, {
            xtype: 'textfield',
            name: 'password',
            inputType: 'password',
            fieldLabel: 'Password',
            allowBlank: false
        }, {
            xtype: 'displayfield',
            hideEmptyLabel: false,
            value: 'Enter any non-blank password'
        }],
        buttons: [{
            text: 'Register',
            formBind: true,
            listeners: {
                click: 'onLoginClick'
            }
        }]
    }
});